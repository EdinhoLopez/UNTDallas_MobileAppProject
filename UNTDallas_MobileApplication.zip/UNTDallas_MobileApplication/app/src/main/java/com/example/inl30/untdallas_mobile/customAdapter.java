package com.example.inl30.untdallas_mobile;



import android.annotation.SuppressLint;
import android.app.Activity;

import android.content.Context;

import androidx.annotation.NonNull;

import android.view.LayoutInflater;

import android.view.View;

import android.view.ViewGroup;

import android.widget.ArrayAdapter;

import android.widget.ImageView;

import android.widget.TextView;


import java.util.List;

/*This class is used to create a custom adapter which allows you to modify
however a listview will display your elements. This customAdapter will only
work with the listview used on the Organizations activity.

 */

public class customAdapter extends ArrayAdapter<Organizations> {



    private Context context;

    private List<Organizations> orgList;


    //The constructor receives a list of objects when created.
    //Will only work for the Organizations activity.
    public customAdapter(Context context, int resource, List<Organizations> objects) {

        super(context, resource, objects);

        this.context = context;

        this.orgList = objects;

    }



    @NonNull
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {



        //Gets the organization that will be displayed based on the position within the array.
        Organizations orgOne = orgList.get(position);

        //Get the inflater and inflate the XML layout for each item

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

        @SuppressLint({"ViewHolder", "InflateParams"}) View view = inflater.inflate(R.layout.custom_layout, null);


        //Each item within the listview will have an image.
        ImageView image = (ImageView) view.findViewById(R.id.icon);

        //Each item within the listview will have a textview to display its title.
        TextView name = (TextView)view.findViewById(R.id.textView);


        //Manually determines what image will be displayed
        //In order to add a new item make sure to add another if statement
        if(orgOne.getEntityID() == 0){
            image.setImageResource(R.drawable.it);
        }
        else if(orgOne.getEntityID()==1){
            image.setImageResource(R.drawable.bio);
        }
        else if(orgOne.getEntityID()==2){
            image.setImageResource(R.drawable.chem);
        }
        else if(orgOne.getEntityID()==3){
            image.setImageResource(R.drawable.pot);
        }
        else if(orgOne.getEntityID()==4){
            image.setImageResource(R.drawable.art);
        }
        else if(orgOne.getEntityID()==5){
            image.setImageResource(R.drawable.sig);
        }
        else{
            image.setImageResource(R.drawable.ic_launcher_background);
        }


        //Limits the numbers of character that can be displayed in an item's title.
        if(orgOne.getOrgName().length() > 20){

            String newName = orgOne.getOrgName().substring(0,18);

            newName = newName + "...";

            name.setText(newName);



        }

        else{

            name.setText(orgOne.getOrgName());

        }


        return view;



    }


}