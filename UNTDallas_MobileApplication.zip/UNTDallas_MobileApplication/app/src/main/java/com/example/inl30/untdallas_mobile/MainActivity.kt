package com.example.inl30.untdallas_mobile

import android.content.Intent

import android.content.pm.PackageManager

import android.content.pm.ResolveInfo

import android.net.Uri

import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity

import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Changes title for the activity
        title = ("UNT Dallas")


        //Checks to make sure that there's a native app to open the material, otherwise it will use the web browser.
        val activities: List<ResolveInfo> = packageManager.queryIntentActivities(
                intent,
                PackageManager.MATCH_DEFAULT_ONLY
        )
        val isIntentSafe: Boolean = activities.isNotEmpty()



        //Creates the buttons that will be used for the user to navigate to different pages.


        //This button is for the canvas Feature
        val canvasButton = findViewById<Button>(R.id.canvasButton)

        //This button is for the Calendar Feature
        val calendarButton = findViewById<Button>(R.id.calendarButton)

        //This button is for the email Feature
        val emailButton = findViewById<Button>(R.id.emailButton)

        //This button is for the Cafeteria Feature
        val cafeteriaButton = findViewById<Button>(R.id.cafeteriaButton)

        //This button is for the to-do Feature
        val todoButton = findViewById<Button>(R.id.todoButton)

        //This button is for the Events Feature
        val eventsButton = findViewById<Button>(R.id.eventButton)

        //This button is for the Organizations Feature
        val organizationButton = findViewById<Button>(R.id.organizationButton)

        //This button is for the Library Feature
        val libraryButton = findViewById<Button>(R.id.libraryButton)

        //This button is for the Maps Feature
        val mapsButton = findViewById<Button>(R.id.mapButton)

        //This button is for the Social Media Feature
        val socialButton = findViewById<Button>(R.id.socialButton)

        //This button is for the Directory Feature
        val directoryButton = findViewById<Button>(R.id.directoryButton)

        //This button is for the Dart Feature
        val dartButton = findViewById<Button>(R.id.dartButton)


       //***********************************************************************************************

        //This creates the intents that will be triggered once a user taps on one of the buttons it will
        //perform the corresponding action to that particular button.


        //Pressing Canvas icon will open the canvas app.
        val canvasPackage = "com.instructure.candroid"
        val canvasPackage2 = "com.instructure.teacher"
        val canvas: Intent = Uri.parse("https://untdallas.instructure.com/").let { webpage ->
            Intent(Intent.ACTION_VIEW, webpage)
        }

        canvasButton.setOnClickListener(){
            canvas(canvasPackage)
            canvasTeacher(canvasPackage2)
            if (isIntentSafe) {
                startActivity(canvas)
            }
        }


        //creates objects to open the calendar for different cellphone manufacturers.
        val playCalendar = "com.google.android.calendar"
        val galaxyCalendar = "com.samsung.android.calendar"
        val genericCalendar = "com.android.calendar"

        //Pressing the calendar button allows you to open your calendar app and add events.
        calendarButton.setOnClickListener(){
            googleCalendar(playCalendar)
            samsungCalendar(galaxyCalendar)
            generalCalendar(genericCalendar)
        }


        //Pressing the email button allows you to see your school information.
        emailButton.setOnClickListener{
            val uri = Uri.parse("http://webmail.unt.edu/")
            val email = Intent(Intent.ACTION_VIEW, uri)
            startActivity(email)
        }


        //Pressing the cafeteria button allows you to see the cafeteria menu.
        cafeteriaButton.setOnClickListener(){
            startActivity(Intent(this@MainActivity, cafeteriaAttempt::class.java))
        }


        //Pressing to-do button opens the to-do list feature.
        todoButton.setOnClickListener(){
            startActivity(Intent(this@MainActivity, ToDoList::class.java))
        }


        //Pressing the events button displays the school events.
        eventsButton.setOnClickListener{
            val uri = Uri.parse("https://calendar.untdallas.edu/")
            val email = Intent(Intent.ACTION_VIEW, uri)
            startActivity(email)
        }


        //Pressing the organizations button allows you to see the school organizations.
        organizationButton.setOnClickListener(){
            startActivity(Intent(this@MainActivity, OrganizationsActivity::class.java))
        }

        //Pressing the library button will open library information.
        libraryButton.setOnClickListener(){
            startActivity(Intent(this@MainActivity, Library::class.java))
        }


        //Pressing the maps button allows you to see the school maps.
        mapsButton.setOnClickListener(){
            startActivity(Intent(this@MainActivity, Maps::class.java))
        }


        //Pressing Social Media will open the social media page and links.
        socialButton.setOnClickListener(){
            startActivity(Intent(this@MainActivity, socialMedia::class.java))
        }


        //Pressing the directory button allows you to see the staff directory.
        directoryButton.setOnClickListener(){
            startActivity(Intent(this@MainActivity, DirectoryActivity::class.java))
        }


        //Pressing the dart button allows the user to see public transportation information.
        dartButton.setOnClickListener(){
            startActivity(Intent(this@MainActivity, Dart::class.java))
        }



    }

    //*****Objects created to call them depending on what apps are installed on device*****



    //Uses the regular Student Canvas application.
    private fun canvas(packageName: String){
        val pm = applicationContext.packageManager
        val intent: Intent? = pm.getLaunchIntentForPackage(packageName)
        intent?.addCategory(Intent.CATEGORY_LAUNCHER)
        if(intent!=null){
            applicationContext.startActivity(intent)
        }
    }


    //Uses the Teacher Canvas application.
    private fun canvasTeacher(packageName: String){
        val pm = applicationContext.packageManager
        val intent: Intent? = pm.getLaunchIntentForPackage(packageName)
        intent?.addCategory(Intent.CATEGORY_LAUNCHER)
        if(intent!=null){
            applicationContext.startActivity(intent)
        }
    }


    //Uses the Google calendar application on most android devices.
    private fun googleCalendar(packageName: String){
        val pm = applicationContext.packageManager
        val intent: Intent? = pm.getLaunchIntentForPackage(packageName)
        intent?.addCategory(Intent.CATEGORY_LAUNCHER)
        if(intent!=null){
            applicationContext.startActivity(intent)
        }
    }

    //Uses the Samsung calendar if running app on Samsung device
    private fun samsungCalendar(packageName: String){
        val pm = applicationContext.packageManager
        val intent: Intent? = pm.getLaunchIntentForPackage(packageName)
        intent?.addCategory(Intent.CATEGORY_LAUNCHER)
        if(intent!=null){
            applicationContext.startActivity(intent)
        }
    }

    //Uses this calendar app instead of the other mentioned above.
    private fun generalCalendar(packageName: String){
        val pm = applicationContext.packageManager
        val intent: Intent? = pm.getLaunchIntentForPackage(packageName)
        intent?.addCategory(Intent.CATEGORY_LAUNCHER)
        if(intent!=null){
            applicationContext.startActivity(intent)
        }
    }


}
