package com.example.inl30.untdallas_mobile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import org.w3c.dom.Text

class directoryInformation : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_directory_information)

        //This array stores an array of strings previous created by DirectoryActivity.
        //This array stores all information related to a specific item. Use its index to get information.
        /*
        For array "moreInfo":
        moreInfo[0] = ID
        moreInfo[1] = First name of item
        moreInfo[2] = Last name of item
        moreInfo[3] = Email of item
        moreInfo[4] = Phone of item
        moreInfo[5] = Position of item
        moreInfo[6] = Picture related to item
         */
        var moreInfo = intent.getStringArrayExtra("info")


        //This variables combines First and Last Name into a new variable.
        var fullName = moreInfo[1] + " " + moreInfo[2]

        setTitle(fullName)

        //This TextView will display the Full Name of the item selected
        val nameBox = findViewById<TextView>(R.id.FullNameFill)

        nameBox.setText(fullName)

        //This TextView will display the phonebox of the item selected
        val phoneBox = findViewById<TextView>(R.id.OffPhoneFill)

        phoneBox.setText(moreInfo[4])

        //This TextView will display the email of the item selected
        val emailBox = findViewById<TextView>(R.id.EmalFill)

        emailBox.setText(moreInfo[3])

        //This TextView will display the position of the item selected
        val positionBox = findViewById<TextView>(R.id.positionFieldFill)

        positionBox.setText(moreInfo[5])

        //This TextView will display the room number of the item selected
        val roomBox = findViewById<TextView>(R.id.roomFieldFill)

        roomBox.setText(moreInfo[6])

        //This ImageView will display the image related to the item selected
        val picBox = findViewById<ImageView>(R.id.dirImage)

        //These statements manually assign a picture to picBox depending on the ID number.
        //If you add a new entry to directory do not forget to add a statement here to display images
        if(moreInfo[0].equals("0")){

            picBox.setImageResource(R.drawable.alsultan)

        }
        else if(moreInfo[0].equals("1")){

            picBox.setImageResource(R.drawable.rambally)
        }
        else if(moreInfo[0].equals("2")){

            picBox.setImageResource(R.drawable.chandler)
        }
        else if(moreInfo[0].equals("3")){

            picBox.setImageResource(R.drawable.hall)
        }
    }
}
