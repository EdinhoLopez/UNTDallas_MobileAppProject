package com.example.inl30.untdallas_mobile

import android.content.Intent

import android.content.pm.PackageManager

import android.content.pm.ResolveInfo

import android.net.Uri

import androidx.appcompat.app.AppCompatActivity

import android.os.Bundle



import kotlinx.android.synthetic.main.activity_social_media.*



class socialMedia : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_social_media)

        title = "Social Media"




        //This variable will get the package name of the Instagram application in case it is installed.
        val activities: List<ResolveInfo> = packageManager.queryIntentActivities(

                intent,

                PackageManager.MATCH_DEFAULT_ONLY

        )

        //This is a null check and makes sure the application is installed.
        val isIntentSafe: Boolean = activities.isNotEmpty()






        //This variable will store the URL address of UNTD's Instagram account.
        val instagram: Intent = Uri.parse("https://www.instagram.com/untdallas/?hl=en").let { webpage ->

            Intent(Intent.ACTION_VIEW, webpage)

        }

        //When this button is clicked Instagram will be launched if the application is available
        instaButton.setOnClickListener {

            if (isIntentSafe) {

                startActivity(instagram)

            }

        }

        //This variable will store the URL address of UNTD's Facebook account.
        val facebook: Intent = Uri.parse("https://www.facebook.com/UNTDallas/").let { webpage ->

            Intent(Intent.ACTION_VIEW, webpage)

        }

        //When this button is clicked Facebook will be launched if the application is available
        facebookApp.setOnClickListener{

            if (isIntentSafe) {

                startActivity(facebook)

            }

        }

        //This variable will store the URL address of UNTD's LinkedIn account.
        val linkedin: Intent = Uri.parse("https://www.linkedin.com/school/university-of-north-texas-at-dallas/").let { webpage ->

            Intent(Intent.ACTION_VIEW, webpage)

        }

        //When this button is clicked LinkedIn will be launched if the application is available
        linkedInButton.setOnClickListener{

            if (isIntentSafe) {

                startActivity(linkedin)

            }

        }

        //This variable will store the URL address of UNTD's Twitter account.
        val twitter: Intent = Uri.parse("https://twitter.com/UNTDallas?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor").let { webpage ->

            Intent(Intent.ACTION_VIEW, webpage)

        }

        //When this button is clicked Twitter will be launched if the application is available
        twitterButton.setOnClickListener{

            if (isIntentSafe) {

                startActivity(twitter)

            }

        }



    }

}