package com.example.inl30.untdallas_mobile

import androidx.appcompat.app.AppCompatActivity

import android.os.Bundle

import androidx.appcompat.app.AlertDialog

import android.widget.Button

import android.widget.ImageView

import android.widget.TextView

import android.widget.Toast

import android.R.string.cancel

import android.app.Dialog

import android.content.DialogInterface

import androidx.core.content.ContextCompat

import java.security.AccessController.getContext





class organizationInformation : AppCompatActivity() {





    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_organization_information)


        //This array will store all the Strings related to an object.
        /*
        Indexes for the moreInfo array. Remember, THEY ARE ALL STRINGS.
        moreInfo[0] stores the entityID of the selected object as a String.
        moreInfo[1] stores the name of the organization.
        moreInfo[2] stores the description of the organization.
        moreInfo[3] stores the name of the president of the organization.
        moreInfo[4] stores the email of the organization.
        moreInfo[5] stores the phone of the organization.
        moreInfo[6] stores the name of the picture of the organization.

         */
        var moreInfo = intent.getStringArrayExtra("info")


        //Stores the place where the president Name will be placed
        var presName = findViewById<TextView>(R.id.presNameFill)

        //Stores the place where the email will be placed
        var email = findViewById<TextView>(R.id.presEmalFill)

        //Stores the place where the phone will be placed
        var phone = findViewById<TextView>(R.id.presPhoneFill)

        //Stores the place where the picture of the organization will be placed
        var pic = findViewById<ImageView>(R.id.orgImage)


        //Sets the title to the name of the organization
        setTitle(moreInfo[1])

        presName.setText(moreInfo[3])

        email.setText(moreInfo[4])

        phone.setText(moreInfo[5])


        //These statements manually assign a picture to pic depending on the picture name value.
        //If you add a new entry to Organization do not forget to add a statement here to display images.
        if(moreInfo[6].equals("it")){
            pic.setImageResource(R.drawable.it)
        }
        else if(moreInfo[6].equals("bio")){
            pic.setImageResource(R.drawable.bio)
        }
        else if(moreInfo[6].equals("chem")){
            pic.setImageResource(R.drawable.chem)
        }
        else if(moreInfo[6].equals("pot")){
            pic.setImageResource(R.drawable.pot)
        }
        else if(moreInfo[6].equals("art")){
            pic.setImageResource(R.drawable.art)
        }
        else if(moreInfo[6].equals("sig")){
            pic.setImageResource(R.drawable.sig)
        }
        else{
            pic.setImageResource(R.drawable.ic_launcher_background)
        }


        //This button will display information related to an organzation once clicked.
        var infoButton = findViewById<Button>(R.id.descInfo)

        //Determines what will happen when the user click on the "Info" button.
        infoButton.setOnClickListener(){

            //An Alert box will be created
            val ad = AlertDialog.Builder(this).create()

            //The title of the alert box will be Description
            ad.setTitle("Description")

            //All the information within moreInfo[2] will be displayed on the alert box
            ad.setMessage(moreInfo[2])

            //Allows the user to manually close the alert box
            ad.setCancelable(true)

            //Allows user to close alert box and sets the button within to display "Ok"
            ad.setButton(Dialog.BUTTON_POSITIVE,"OK") { dialog, which -> finish() }

            //Shows the alert box
            ad.show()

        }







    }











}