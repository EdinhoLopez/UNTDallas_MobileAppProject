package com.example.inl30.untdallas_mobile;

/*
This class will work with DBHandler_v2 in order
to implement the database. DBHandler will create an
object from this class. This class will also be used by
the corresponding activity fo the feature.

Overall, a standard class with setters and getters for
each variable.
*/

public class Organizations {



    private int entityID;

    private String orgName;

    private String presName;

    private String presEmail;

    private String presPhone;

    private String orgDesc;

    private String orgPic;



    public Organizations()

    {

    }

    public Organizations(int entityID,String orgName,String presName,String presEmail,String presPhone,String orgDesc,String orgPic)

    {

        this.entityID = entityID;

        this.orgName = orgName;

        this.presName = presName;

        this.presEmail = presEmail;

        this.presPhone = presPhone;

        this.orgDesc = orgDesc;

        this.orgPic = orgPic;



    }

    public void setEntityID(int entityID) {

        this.entityID = entityID;

    }



    public int getEntityID() {

        return entityID;

    }



    public void setOrgName(String orgName) {

        this.orgName = orgName;

    }

    public String getOrgName() {

        return orgName;

    }





    public String getPresName() {

        return presName;

    }



    public void setPresName(String presName) {

        this.presName = presName;

    }



    public String getPresEmail() {

        return presEmail;

    }



    public void setPresEmail(String presEmail) {

        this.presEmail = presEmail;

    }



    public String getPresPhone() {

        return presPhone;

    }



    public void setPresPhone(String presPhone) {

        this.presPhone = presPhone;

    }



    public String getOrgDesc() {

        return orgDesc;

    }



    public void setOrgDesc(String orgDesc) {

        this.orgDesc = orgDesc;

    }



    public String getOrgPic() {

        return orgPic;

    }



    public void setOrgPic(String orgPic) {

        this.orgPic = orgPic;

    }

}