package com.example.inl30.untdallas_mobile

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView

class DirectoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_directory)

        setTitle("Directory")

        //Creates an object from the DBHandler_v2 class.
        //This object is used to access the database. Use its methods to access the database.
        var db = DBHandler_v2(this);


        //Creates and adds Directory objects to the database.
        //In order to add an new entry simply add an entry. Don't forget about its image too.
        db.addDirec(Directory(0,"Saif","Al-sultan","SaifAlsultan@my.untdallas.edu",
                "456456456", "IT Professor", "FH 222","Alsultan"))

        db.addDirec(Directory(1,"Gerard","Rambally","GerardRambally@my.untdallas.edu",
                "456123456", "IT Professor", "FH 232","Rambally"))

        db.addDirec(Directory(2,"Richard","Chandler","RichardChandler@my.untdallas.edu",
                "456789900", "Math Professor", "FH 236","Chandler"))

        db.addDirec(Directory(3,"Farid","Hallouche","FaridHallouche@my.untdallas.edu",
                "456576394", "IT Professor", "FH 240","Hallouche"))


        //Gets all Directory objects stored within the database.
        var dirList = db.allDirectory

        //Turns dirList into an array while keeping the objects.
        var dirArray = dirList.toTypedArray()

        //This array will be used to store the names of each entry.
        var names = emptyArray<String>()

        //Loops through each stored object and gets their first and last name.
        //The full names are stored within array "names".
        for(dir in dirArray){

            var fullName = dir.fName + " " + dir.lName

            names = names + fullName

        }

        for ( Org in dirList) {


            db.deleteDirectory(Org)

        }



        //Creates the adapter for the listview of the activity. Uses the array "names" in its constructor.
        var dirAdapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names)

        //Listview for the entire activity.
        var dirListView = findViewById<ListView>(R.id.directoryListView)

        //Sets the adapter of the listview of the activity.
        dirListView.adapter = dirAdapter

        //Sets a listener used whenever an item in the listview is clicked.
        //The "pos" value is used to determine which item is being clicked and used to access objects in the array.
        dirListView.setOnItemClickListener(AdapterView.OnItemClickListener { list, v, pos, id ->

            //This Intent stores a new activity that will be launched when an item is clicked.
            val intentOne = Intent(applicationContext,directoryInformation::class.java)

            //This variable stores a Directory object. This object will allow access to its variables.
            //The Directory object comes from the array storing all Directory objects.
            var obj = dirArray[pos]

            //This array of strings stores all information related to the object selected.
            var infoArray:Array<String> = arrayOf(obj.entityID.toString(),obj.fName,obj.lName,obj.sEmail

                    ,obj.sPhone,obj.sPosition,obj.sPicture)

            //This statement uses the intent previously created in order to pass on an array.
            //The array that is passed on will be used to display the information of the selected item.
            intentOne.putExtra("info",infoArray)

            //The directoryInformation activity is launched.
            startActivity(intentOne)

        })



    }
}
