package com.example.inl30.untdallas_mobile



import androidx.appcompat.app.AppCompatActivity

import android.os.Bundle

import android.view.View

import android.widget.Button

import android.widget.ListView

import android.widget.ArrayAdapter



class cafeteriaAttempt : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_cafeteria_attempt)




        //Button that will display breakfast when pressed
        var breakfast = findViewById<Button>(R.id.leftB)

        //Button that will display lunch when pressed
        var lunch = findViewById<Button>(R.id.centerB)

        //Button that will display dinner when pressed
        var dinner = findViewById<Button>(R.id.rightB)


        //This array will be used to store the names of all the breakfast items.
        var breakfastOne = emptyArray<String>()

        //This array will be used to store the names of all the lunch items.
        var LunchOne = emptyArray<String>()

        //This array will be used to store the names of all the dinner items.
        var dinnerOne = emptyArray<String>()

        //This array will store the Cafeteria object that get inputted into the database.
        //These Cafeteria objects will be used later on to create the listview
        var allCafe = emptyArray<Cafeteria>()

        //Creates an object from the DBHandler_v2 class.
        //This object is used to access the database. Use its methods to access the database.
        var db = DBHandler_v2(this);

        //Creates an object from cafeteria and stores it in the database.
        //These object are also stored in the array allCafe.
        //Creating a Cafeteria object requires three values: ID (int), FoodType(String), FoodDescription(String).

        //Cafeteria objects related to breakfast are inserted here
        var test = db.addCafeteria(Cafeteria(0,"breakfast","Ginger Grilled Chicken"))
        allCafe = allCafe + test
        test = db.addCafeteria(Cafeteria(1,"breakfast","Breakfast Sandwich"))
        allCafe = allCafe + test
        test =db.addCafeteria(Cafeteria(2,"breakfast","Omelets"))
        allCafe = allCafe + test
        test =db.addCafeteria(Cafeteria(3,"breakfast","Biscuit Chicken"))
        allCafe = allCafe + test

        //Cafeteria objects related to lunch are inserted here

        test =db.addCafeteria(Cafeteria(4,"lunch","Fiesta Grilled Steak"))
        allCafe = allCafe + test
        test =db.addCafeteria(Cafeteria(5,"lunch","Peach BBQ"))
        allCafe = allCafe + test
        test =db.addCafeteria(Cafeteria(6,"lunch","Fried Catfish"))
        allCafe = allCafe + test
        test =db.addCafeteria(Cafeteria(7,"lunch","Sausage & Bell Peppers"))
        allCafe = allCafe + test
        test = db.addCafeteria(Cafeteria(8,"lunch","Montreal Chicken"))
        allCafe = allCafe + test

        //Cafeteria objects related to dinner are inserted here

        test = db.addCafeteria(Cafeteria(9,"dinner","Ginger Grilled Chicken"))
        allCafe = allCafe + test
        test =db.addCafeteria(Cafeteria(10,"dinner","Beef Tips w/ Buttered Noodles"))
        allCafe = allCafe + test
        test =db.addCafeteria(Cafeteria(11,"dinner","Pepper Steak"))
        allCafe = allCafe + test
        test = db.addCafeteria(Cafeteria(12,"dinner","Beef & Macaroni"))
        allCafe = allCafe + test
        test =db.addCafeteria(Cafeteria(13,"dinner","Oven Fried Chicken"))
        allCafe = allCafe + test

        //This loops through all objects in the allCafe array.
        //This loop inserts values into an array depending on the foodType of the object.
        //Remember that we must display the name of the item which is variable foodDescription
        for(cafe in allCafe){

            if(cafe.foodType.equals("breakfast")){
                breakfastOne = breakfastOne + cafe.foodDescription
            }
            else if(cafe.foodType.equals("lunch")){
                LunchOne = LunchOne + cafe.foodDescription
            }
            else if(cafe.foodType.equals("dinner")){
                dinnerOne = dinnerOne + cafe.foodDescription
            }

        }


        //Creates an adapters that can be inserted into a listview.

        //Adapter that can display the Breakfast items.
        val adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,breakfastOne);

        //Adapter that can display the Lunch items.
        val adapterOne = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,LunchOne);

        //Adapter that can display the Dinner items.
        val adapterTwo = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,dinnerOne);


        //This is the only listview within the whole activity.
        var simpleList = findViewById<View>(R.id.simpleListView) as ListView


        //Sets the initial adapter of the listview to be the one for Breakfast.
        simpleList.setAdapter(adapter)

        //Sets the initial title of the activity to breakfast. Will be changed later.
        setTitle("Breakfast")


        //When you click on the breakfast button the listview gets the corresponding adapter.
        //Clicking the lunch button sets the adapter of the listview to the lunch adapter. The listview stays the same.
        breakfast.setOnClickListener(){

            simpleList.setAdapter(adapter)

            setTitle("Breakfast")

        }

        lunch.setOnClickListener(){

            simpleList.setAdapter(adapterOne)

            setTitle("Lunch")

        }

        dinner.setOnClickListener(){

            simpleList.setAdapter(adapterTwo)

            setTitle("Dinner")

        }


    }

}