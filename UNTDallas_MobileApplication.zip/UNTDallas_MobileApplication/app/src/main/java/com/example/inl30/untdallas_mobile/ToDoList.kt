package com.example.inl30.untdallas_mobile

import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity;

import kotlinx.android.synthetic.main.activity_to_do_list.*

class ToDoList : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_to_do_list)
        setSupportActionBar(toolbar)

        fab.setImageResource(R.drawable.todo)

        fab.setOnClickListener { view ->

        }

    }

}
