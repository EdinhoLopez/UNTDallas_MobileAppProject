package com.example.inl30.untdallas_mobile;

/*
This class will work with DBHandler_v2 in order
to implement the database. DBHandler will create an
object from this class. This class will also be used by
the corresponding activity fo the feature.

Overall, a standard class with setters and getters for
each variable.
*/


public class Directory {



    private int entityID;

    private String FName;

    private String LName;

    private String SEmail;

    private String SPhone;

    private String SPosition;

    private String SRoom;

    private String SPicture;



    public Directory()

    {

    }

    public Directory(int entityID,String FName,String LName,String SEmail,String SPhone,String SPosition,String SRoom,String SPicture)

    {

        this.entityID =entityID;

        this.FName = FName;

        this.LName = LName;

        this.SEmail = SEmail;

        this.SPhone = SPhone;

        this.SPosition = SPosition;

        this.SRoom = SRoom;

        this.SPicture = SPicture;



    }





    public int getEntityID() {

        return entityID;

    }



    public void setEntityID(int entityID) {

        this.entityID = entityID;

    }



    public String getFName() {

        return FName;

    }



    public void setFName(String FName) {

        this.FName = FName;

    }



    public String getLName() {

        return LName;

    }



    public void setLName(String LName) {

        this.LName = LName;

    }



    public String getSEmail() {

        return SEmail;

    }



    public void setSEmail(String SEmail) {

        this.SEmail = SEmail;

    }



    public String getSPhone() {

        return SPhone;

    }



    public void setSPhone(String SPhone) {

        this.SPhone = SPhone;

    }



    public String getSPosition() {

        return SPosition;

    }



    public void setSPosition(String SPosition) {

        this.SPosition = SPosition;

    }



    public String getSRoom() {

        return SRoom;

    }



    public void setSRoom(String SRoom) {

        this.SRoom = SRoom;

    }



    public String getSPicture() {

        return SPicture;

    }



    public void setSPicture(String SPicture) {

        this.SPicture = SPicture;

    }

}