package com.example.inl30.untdallas_mobile;



import android.annotation.SuppressLint;

        import android.content.ContentValues;

        import android.content.Context;

        import android.database.Cursor;

        import android.database.sqlite.SQLiteDatabase;

        import android.database.sqlite.SQLiteOpenHelper;

        import java.util.ArrayList;

        import java.util.List;



public class DBHandler_v2 extends SQLiteOpenHelper{



    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "Capstone";



    // Organizations Table Columns names

    private static final String TABLE_ORGANIZATIONS = "Organizations";

    private static final String ENTITY_ID = "entityID";

    private static final String ORG_NAME = "orgName";

    private static final String PRES_NAME = "presName";

    private static final String PRES_EMAIL = "presEmail";

    private static final String PRES_PHONE = "presPhone";

    private static final String ORG_DESC = "orgDesc";

    private static final String ORG_PIC = "orgPic";



    // Directory Table Columns names

    private static final String TABLE_DIRECTORY = "Directory";

    private static final String ENTITY_ID_DIRECTORY = "entityID";

    private static final String SF_NAME = "FName";

    private static final String SL_NAME = "LName";

    private static final String S_EMAIL = "SEmail";

    private static final String S_PHONE = "SPhone";

    private static final String S_POSITION = "SPosition";

    private static final String S_ROOM = "roomLocation";

    private static final String S_PIC = "SPicture";

    //Cafeteria Table Columns Names

    private static final String TABLE_CAFETERIA = "Cafeteria";

    private static final String FOOD_TYPE = "foodType";

    private static final String FOOD_ID = "foodID";

    private static final String FOOD_DESCRIPTION = "foodDescription";


    public DBHandler_v2(Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override

    public void onCreate(SQLiteDatabase db) {



        //Creates the Organizations Table

        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_ORGANIZATIONS + "("

                + ENTITY_ID + " INTEGER PRIMARY KEY," + ORG_NAME + " TEXT,"

                + PRES_NAME + " TEXT," + PRES_EMAIL + " TEXT,"

                + PRES_PHONE + " TEXT," + ORG_DESC + " TEXT,"

                + ORG_PIC + " TEXT" + ")";

        db.execSQL(CREATE_CONTACTS_TABLE);

        //Creates the Directory Table

        String CREATE_DIRECTORY_TABLE = "CREATE TABLE " + TABLE_DIRECTORY + "("

                + ENTITY_ID_DIRECTORY + " INTEGER PRIMARY KEY," + SF_NAME + " TEXT,"

                + SL_NAME + " TEXT," + S_EMAIL + " TEXT,"

                + S_PHONE + " TEXT," + S_POSITION + " TEXT,"

                + S_PIC + " TEXT,"

                + S_ROOM + " TEXT" + ")";

        db.execSQL(CREATE_DIRECTORY_TABLE);

        String CREATE_CAFETERIA_TABLE = "CREATE TABLE " + TABLE_CAFETERIA + "("

                + FOOD_ID + " INTEGER PRIMARY KEY," + FOOD_TYPE + " TEXT,"

                + FOOD_DESCRIPTION + " TEXT)";


        db.execSQL(CREATE_CAFETERIA_TABLE);



    }

    @Override

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

// Drop older tables if existed

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORGANIZATIONS);

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DIRECTORY);

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CAFETERIA);

// Creating tables again

        onCreate(db);

    }



    ///////////////////////////////////////////////////////////////////////////////////////
    //The methods related to the Organization Table start here.


    // Adding new organization

    public void addOrg(Organizations org) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();



        //Inserting columns and their values to a values variable

        values.put(ENTITY_ID, org.getEntityID()); //!!!!!!!!!!!!!

        values.put(ORG_NAME, org.getOrgName());

        values.put(PRES_NAME, org.getPresName());

        values.put(PRES_EMAIL, org.getPresEmail());

        values.put(PRES_PHONE, org.getPresPhone());

        values.put(ORG_DESC, org.getOrgDesc());

        values.put(ORG_PIC, org.getOrgPic());



        // Inserting Row

        db.insert(TABLE_ORGANIZATIONS, null, values);

        db.close(); // Closing database connection


    }



    // Getting one Organization

    public Organizations getOrganization(int id) {

        SQLiteDatabase db = this.getReadableDatabase();

        @SuppressLint("Recycle") Cursor cursor = db.query(TABLE_ORGANIZATIONS, new String[] { ENTITY_ID,

                        ORG_NAME, PRES_NAME, PRES_EMAIL,PRES_PHONE,ORG_DESC,ORG_PIC }, ENTITY_ID + "=?",

                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null)

            cursor.moveToFirst();

        // return Organization

        assert cursor != null;

        return new Organizations(Integer.parseInt(cursor.getString(0)),

                cursor.getString(1), cursor.getString(2),cursor.getString(3),

                cursor.getString(4),cursor.getString(5),cursor.getString(6));

    }



    // Getting All Organizations

    public List<Organizations> getAllOrganizations() {

        List<Organizations> orgList = new ArrayList<Organizations>();

// Select All Query

        String selectQuery = "SELECT * FROM " + TABLE_ORGANIZATIONS;

        SQLiteDatabase db = this.getWritableDatabase();

        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(selectQuery, null);

// looping through all rows and adding to list

        if (cursor.moveToFirst()) {

            do {

                Organizations org = new Organizations();

                org.setEntityID(Integer.parseInt(cursor.getString(0)));

                org.setOrgName(cursor.getString(1));

                org.setPresName(cursor.getString(2));

                org.setPresEmail(cursor.getString(3));

                org.setPresPhone(cursor.getString(4));

                org.setOrgDesc(cursor.getString(5));

                org.setOrgPic(cursor.getString(6));



// Adding contact to list

                orgList.add(org);

            } while (cursor.moveToNext());

        }

// return contact list

        return orgList;

    }



    // Getting Organizations Count

    public int getOrganizationsCount() {

        String countQuery = "SELECT * FROM " + TABLE_ORGANIZATIONS;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(countQuery, null);

        cursor.close();

// return count

        return cursor.getCount();

    }



    // Updating an organization

    public int updateOrganization(Organizations org) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();



        values.put(ORG_NAME, org.getOrgName());

        values.put(PRES_NAME, org.getPresName());

        values.put(PRES_EMAIL, org.getPresEmail());

        values.put(PRES_PHONE, org.getPresPhone());

        values.put(ORG_DESC, org.getOrgDesc());

        values.put(ORG_PIC, org.getOrgPic());



// updating row

        return db.update(TABLE_ORGANIZATIONS, values, ENTITY_ID + " = ?",

                new String[]{String.valueOf(org.getEntityID())});

    }



    // Deleting an organization

    public void deleteOrganization(Organizations org) {

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_ORGANIZATIONS, ENTITY_ID + " = ?",

                new String[] { String.valueOf(org.getEntityID()) });

        db.close();

    }



    ////////////////////////////////////////////////////////////////////////////////////
    //The methods related to the Directory Table start here.


    public void addDirec(Directory dir) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();



        //Inserting columns and their values to a values variable

        values.put(ENTITY_ID_DIRECTORY, dir.getEntityID()); //!!!!!!!!!!!!!

        values.put(SF_NAME, dir.getFName());

        values.put(SL_NAME, dir.getLName());

        values.put(S_EMAIL, dir.getSEmail());

        values.put(S_PHONE, dir.getSPhone());

        values.put(S_POSITION, dir.getSPosition());

        values.put(S_ROOM, dir.getSRoom());

        values.put(S_PIC, dir.getSPicture());



        // Inserting Row

        db.insert(TABLE_DIRECTORY, null, values);

        db.close(); // Closing database connection

    }



    // Getting one Directory

    public Directory getDirectory(int id) {

        SQLiteDatabase db = this.getReadableDatabase();

        @SuppressLint("Recycle") Cursor cursor = db.query(TABLE_DIRECTORY, new String[] { ENTITY_ID_DIRECTORY,

                        SF_NAME, SL_NAME, S_EMAIL,S_PHONE,S_POSITION,S_ROOM,S_PIC }, ENTITY_ID_DIRECTORY + "=?",

                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null)

            cursor.moveToFirst();

        // return Organization

        assert cursor != null;

        return new Directory(Integer.parseInt(cursor.getString(0)),

                cursor.getString(1), cursor.getString(2),cursor.getString(3),

                cursor.getString(4),cursor.getString(5),cursor.getString(6),

                cursor.getString(7));

    }



    // Getting All Organizations

    public List<Directory> getAllDirectory() {

        List<Directory> dirList = new ArrayList<Directory>();

// Select All Query

        String selectQuery = "SELECT * FROM " + TABLE_DIRECTORY;

        SQLiteDatabase db = this.getWritableDatabase();

        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(selectQuery, null);

// looping through all rows and adding to list

        if (cursor.moveToFirst()) {

            do {

                Directory dir = new Directory();

                dir.setEntityID(Integer.parseInt(cursor.getString(0)));

                dir.setFName(cursor.getString(1));

                dir.setLName(cursor.getString(2));

                dir.setSEmail(cursor.getString(3));

                dir.setSPhone(cursor.getString(4));

                dir.setSPosition(cursor.getString(5));

                dir.setSRoom(cursor.getString(6));

                dir.setSPicture(cursor.getString(7));



// Adding contact to list

                dirList.add(dir);

            } while (cursor.moveToNext());

        }

// return contact list

        return dirList;

    }



    // Getting Organizations Count

    public int getDirectoryCount() {

        String countQuery = "SELECT * FROM " + TABLE_DIRECTORY;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(countQuery, null);

        cursor.close();

// return count

        return cursor.getCount();

    }



    // Updating an organization

    public int updateDirectory(Directory dir) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();



        values.put(SF_NAME, dir.getFName());

        values.put(SL_NAME, dir.getLName());

        values.put(S_EMAIL, dir.getSEmail());

        values.put(S_PHONE, dir.getSPhone());

        values.put(S_POSITION, dir.getSPosition());

        values.put(S_ROOM, dir.getSRoom());

        values.put(S_PIC, dir.getSPicture());



// updating row

        return db.update(TABLE_DIRECTORY, values, ENTITY_ID_DIRECTORY + " = ?",

                new String[]{String.valueOf(dir.getEntityID())});

    }



    // Deleting an organization

    public void deleteDirectory(Directory dir) {

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_DIRECTORY, ENTITY_ID_DIRECTORY + " = ?",

                new String[] { String.valueOf(dir.getEntityID()) });

        db.close();

    }

////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Methods for the Cafeteria Table start here

    public Cafeteria addCafeteria(Cafeteria cafe) {

        Cafeteria returnCafe = cafe;
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();


        //Inserting columns and their values to a values variable

        values.put(FOOD_ID, cafe.getFoodID()); //!!!!!!!!!!!!!

        values.put(FOOD_TYPE, cafe.getFoodType());

        values.put(FOOD_DESCRIPTION, cafe.getFoodDescription());


        // Inserting Row

        db.insert(TABLE_CAFETERIA, null, values);

        db.close(); // Closing database connection

        return returnCafe;

    }

    public Cafeteria getCafeteria(int id) {

        SQLiteDatabase db = this.getReadableDatabase();

        @SuppressLint("Recycle") Cursor cursor = db.query(TABLE_CAFETERIA, new String[] { FOOD_ID,

                        FOOD_TYPE,FOOD_DESCRIPTION }, FOOD_ID + "=?",

                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null)

            cursor.moveToFirst();

        // return Organization

        assert cursor != null;

        return new Cafeteria(Integer.parseInt(cursor.getString(0)),

                cursor.getString(1), cursor.getString(2));

    }

    public int getCafeteriaCount() {

        String countQuery = "SELECT * FROM " + TABLE_CAFETERIA;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(countQuery, null);

        cursor.close();

// return count

        return cursor.getCount();

    }

    // Updating an organization

    public int updateCafeteria(Cafeteria cafe) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();



        values.put(FOOD_TYPE, cafe.getFoodType());

        values.put(FOOD_DESCRIPTION, cafe.getFoodDescription());



// updating row

        return db.update(TABLE_CAFETERIA, values, FOOD_ID + " = ?",

                new String[]{String.valueOf(cafe.getFoodID())});

    }

    // Deleting an organization

    public void deleteCafeteria(Cafeteria cafe) {

        SQLiteDatabase db = this.getWritableDatabase();

        String statement = "DELETE FROM "+TABLE_CAFETERIA;
        db.execSQL(statement);
        db.close();

    }


}