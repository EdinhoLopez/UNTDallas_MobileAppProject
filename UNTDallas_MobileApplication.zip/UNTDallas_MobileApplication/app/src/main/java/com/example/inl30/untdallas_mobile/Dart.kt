package com.example.inl30.untdallas_mobile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Dart : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dart)
        setTitle("Dart Schedule")
    }
}
