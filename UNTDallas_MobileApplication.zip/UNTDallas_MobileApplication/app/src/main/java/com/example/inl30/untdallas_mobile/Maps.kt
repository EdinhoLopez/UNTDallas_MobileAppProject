package com.example.inl30.untdallas_mobile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Maps : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        setTitle("Maps")
    }
}
