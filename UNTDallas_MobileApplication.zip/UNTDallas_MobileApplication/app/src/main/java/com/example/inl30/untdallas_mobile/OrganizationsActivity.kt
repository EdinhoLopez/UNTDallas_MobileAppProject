package com.example.inl30.untdallas_mobile



import android.content.Intent

import androidx.appcompat.app.AppCompatActivity

import android.os.Bundle

import android.util.Log

import android.view.View

import android.view.ViewParent

import android.widget.Adapter

import android.widget.AdapterView

import android.widget.ArrayAdapter

import android.widget.ListView

import kotlinx.android.synthetic.main.activity_organizations.*



class OrganizationsActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_organizations)

        setTitle("Organizations")

        //This variable stores the database instance. Use its functions to access the database.
        var db = DBHandler_v2(this);


        //Adds an organization to the database. This is the ITSO organization
        db.addOrg(Organizations(0,"Information Technology Student Association",

                "Oluwatosin Olubode","itstudentorg@untdallas.edu","972.338.1781",

                "Information Technology Student Organization (ITSO) is an academic " +

                        "and professional organization developed to foster learning, ideas, knowledge," +

                        " collaboration, networking, and team spirit. The organization is directed to students" +

                        " who are enrolled or are interested in information technology and computer science." +

                        " ITSO seeks to partner with professional organizations in the technology industry so as" +

                        " to build a strong learning capacity, networking, professionalism, collaboration, and" +

                        " mentoring for members. The organization serves the interests of the students, faculty," +

                        " and administration of the University. In addition, ITSO will bring benefits to the community" +

                        " as part of an organization in the University of North Texas at Dallas.","it"))


        //Adds an organization to the database. This is the Biology club organization
        db.addOrg(Organizations(1,"Biology Club","Marcela Torres","MarcelaTorres@my.unt.edu",

                "972.338.1781",

                "The Biology Club is the gathering of Biology majors and any students interested in Biology to" +

                        " discuss the field as a whole. The group is also interested in studying the different content areas" +

                        " of Biology that are offered in the Bachelors of Science in Biology degree plan, so that all students" +

                        " who are either Biology majors or taking Biology classes will have the tools needed to succeed. The" +

                        " objectives (mission) of The University of North Texas at Dallas Biology Club is to spark an interest in" +

                        " biology and the sciences to students of many different levels. Community service, teamwork, speakers," +

                        " new scientific discoveries,&nbsp;and communication will allow students to enjoy and learn more about the " +

                        "aspects of biology that are unattainable within the classroom setting. By attending Biology Club we hope " +

                        "that the students of UNT Dallas will strengthen their interest in the sciences.","bio"))


        //Adds an organization to the database. This is the Criminal Justice organization
        db.addOrg(Organizations(2,"Criminal Justice Student Association (CJSA)","Alma Alejandro",

                "almaalejandro@my.unt.edu","972.338.1781",

                "The Criminal Justice Students Association is an organization designed to encourage students interested in" +

                        " criminal justice, as well as other interested factions of the University of North Texas at Dallas to share" +

                        " interests and ideas thereby supplementing and enriching our overall learning environment. The Association will" +

                        " assist in the expansion of programs of an educational and cultural nature which will serve the interests of" +

                        " the students, faculty, and administration of the University of North Texas at Dallas. In addition, the outside" +

                        " community will benefit from the existence of The Association at the University of North Texas at Dallas.","chem"))


        //Adds an organization to the database. This is the Gaming organization
        db.addOrg(Organizations(3,"Gaming, Anime & Comics Club","Alejandro Valle","alejandrovalle@my.untdallas.edu",

                "972.338.1781",

                "The Gaming, Anime, and Comics Club purpose is to provide a social gathering spot where members can share a common interest" +

                        " with other members and introduce new ones. It is an organization for members to make new friends and gain" +

                        " new fellowship for their time here at UNT Dallas and beyond.\n" +

                        "Mission Statement:\n" +

                        "a) To further promote interest in comics, anime, manga, movies and video games.\n" +

                        "\n" +

                        "b) To provide and create greater fellowship among students.\n" +

                        "\n" +

                        "c) To represent student needs and wants regarding comics, anime, manga, movies and video games.\n" +

                        "\n" +

                        "d) To provide a forum for the presentation of innovative ideas to the benefit of the University community.","pot"))


        //Adds an organization to the database. This is the Pre-health Professions organization
        db.addOrg(Organizations(4,"Pre-Health Professions Club","Laquze Morris","Laquzemorris@my.untdallas.edu",

                "972.338.1781",

                "The purpose of UNT Dallas Pre-Health Professions Society is to prepare pre-health students for entry into their" +

                        " respective graduate programs following their career at UNTD. Our goal is to enhance not only our student members’" +

                        " likelihood to succeed in their health career, but create a community of like-minded students that inspire and challenge" +

                        " each other to achieve ambitious goals. To achieve this goal, we will use several methods. We will give our members opportunities" +

                        " to attend informative lecture-style meetings held by local health professionals, current professional students, and science" +

                        " professors focused on augmenting student pre-professional development. We also will provide academic resources such as study" +

                        " groups and preparatory materials for student taking graduate-level entrance tests such as the MCAT, DAT, GRE, etc. In addition," +

                        " we will organize community service events and shadowing opportunities with the goal of enhancing student’s overall graduate" +

                        " application attractiveness. ","art"))


        //Adds an organization to the database. This is the Sigma Lambda Gamma National Sorority organization
        db.addOrg(Organizations(5,"Sigma Lambda Gamma National Sorority, Inc. ","Jovanna Moreno","slguntd.president@gmail.com",

                "972.338.1781",

                "Recognizing our responsibility to the progression of a positive global community, we stress the importance of morals, ethics," +

                        " and education in our daily lives so that we serve the needs of our neighbors through a mutual respect and understanding of" +

                        " our varying cultures.","sig"))




        //This is the variable that will hold the main listview
        var simpleList: ListView

        //This is the array to hold the Organization objects
        var orgListing = arrayOf("")

        //Counts the number of objects stored in the orgListing
        var count = 0




        //This list of Organizations gets filled with organization objects from the database.
        var orgs: List<Organizations>  = db.allOrganizations;

        //This array gets all the objects from the orgs List.
        //Arrays are easier to use to utilize orgsArray to access the objects
        var orgsArray = orgs.toTypedArray()


        //This loop deletes all the organizations within the database
        //The objects are stored in the array so it is okay.
        //Once the app is created again the organizations are re-inserted.
        //This loops helps keep the organizations up to date.
        for ( Org in orgs) {

            db.deleteOrganization(Org)

            count = count + 1


        }




        //This adapter is an object from another class that was created.
        //This adapter will determine how each organization square is displayed in the list.
        val adapter = customAdapter(this, 0, orgs)

        //This is the listView of the main page.
        simpleList = findViewById<View>(R.id.simpleListView) as ListView

        //The adapter we previously created gets plugged-in to the listView
        //The adapter can be changed to any other that is offered by android
        //The customAdapter class can also be changed to display the list any other way
        simpleList.setAdapter(adapter)




        //This is the Listener that determines what happens when you click on an item in the listView
        //The text within the function is grey due to using some redundant code, it is okay.
        simpleList.setOnItemClickListener(AdapterView.OnItemClickListener { list, v, pos, id ->


            //This variable finds the activity that will be called when you click on an item
            val intentOne = Intent(applicationContext,organizationInformation::class.java)

            //This is an individual object from the orgsArray.
            //The object will be determined based on which item is clicked.
            var obj = orgsArray[pos]


            //An array is created that will store all the info from the selected object
            var infoArray:Array<String> = arrayOf(obj.entityID.toString(),obj.orgName,obj.orgDesc,obj.presName

                    ,obj.presEmail,obj.presPhone,obj.orgPic)


            //The array we created gets passed to the organizationInformation class
            //We will access this array in the other class so we can have the same information between classes
            intentOne.putExtra("info",infoArray)

            //We start the organizationInformation activity
            startActivity(intentOne)

        })




    }









}






