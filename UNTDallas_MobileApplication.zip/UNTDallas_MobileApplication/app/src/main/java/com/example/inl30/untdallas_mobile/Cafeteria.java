package com.example.inl30.untdallas_mobile;
/*
This class will work with DBHandler_v2 in order
to implement the database. DBHandler will create an
object from this class. This class will also be used by
the corresponding activity fo the feature.

Overall, a standard class with setters and getters for
each variable.
*/

public class Cafeteria {

    private int foodID;

    private String foodType;

    private String foodDescription;

    public Cafeteria()
    {

    }

    public Cafeteria(int foodID, String foodType, String foodDescription)
    {

        this.foodID = foodID;
        this.foodType = foodType;
        this.foodDescription = foodDescription;

    }


    public int getFoodID() {
        return foodID;
    }

    public void setFoodID(int foodID) {
        this.foodID = foodID;
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public String getFoodDescription() {
        return foodDescription;
    }

    public void setFoodDescription(String foodDescription) {
        this.foodDescription = foodDescription;
    }
}
